 load('data.mat'); % donn�es machin
 % apprentissage
 theta =   train_toto(X, y, options);
 % pr�diction
 yhat =  predict_toto(Xtest, theta);
 % affichage des r�sulats
 show_toto(X, y, model, Xtest, yhat)
